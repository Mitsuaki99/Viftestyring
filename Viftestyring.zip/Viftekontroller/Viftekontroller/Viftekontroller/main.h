/*
 * main.h
 *
 * Created: 24.04.2023 18:08:54
 *  Author: mitsu
 */ 


#ifndef MAIN_H_
#define MAIN_H_

void USART3_init(void);
void ADC0_init(void);
uint16_t ADC0_read(void);
void Auto(void);
void Viftekontroll2(void);
void Viftekontroll3(void);
void Viftekontroll_off(void);
void Diagnostics(void);
void TCA0_init(void);
void PORT_init(void);
void USART3_sendString(char *str);
void USART3_menu_overview(void);
void menu_system(void);
char USART3_receive(void);

#endif /* MAIN_H_ */