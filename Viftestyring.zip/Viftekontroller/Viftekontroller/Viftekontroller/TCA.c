/*
 * TCA.c
 *
 * Created: 24.04.2023 18:30:18
 *  Author: mitsu
 */ 

#define F_CPU 4000000UL // Definerer CPU frekvensen for delay funksjonen
#define PERIOD_VALUE (0x14) //Setter perioden til 20

#include <avr/io.h>

void TCA0_init(void)
{
	/* Setter b�lgeform utganger p� PORT D */
	PORTMUX.TCAROUTEA = PORTMUX_TCA0_PORTD_gc;
	TCA0.SINGLE.CTRLB = TCA_SINGLE_CMP0EN_bm | TCA_SINGLE_CMP1EN_bm | TCA_SINGLE_CMP2EN_bm/* Skrur p� "compare channel 0, 1, 2" */
	| TCA_SINGLE_WGMODE_DSBOTTOM_gc; /* Setter dual - slope PWM modus */
	
	/* Setter PWM frekvens og arbeidssyklus */
	TCA0.SINGLE.PERBUF = PERIOD_VALUE;
	TCA0.SINGLE.CMP0BUF = 0;
	TCA0.SINGLE.CTRLA = TCA_SINGLE_CLKSEL_DIV4_gc /* Setter "clock source" ( sys_clk /4) */
	| TCA_SINGLE_ENABLE_bm; /* Starter timeren */
}