/*
 * Viftekontroller.c
 *
 * Created: 15.03.2023 12:55:50
 * Author : mitsu
 */ 
#define F_CPU 4000000UL // Definerer CPU frekvensen for delay funksjonen

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include "main.h"


int main(void)
{
	PORT_init();
	TCA0_init();
	ADC0_init();
	USART3_init();
	USART3_menu_overview();
	USART3_receive();
	
	sei();
	
	while(1)
	{
		menu_system();
	}
}
