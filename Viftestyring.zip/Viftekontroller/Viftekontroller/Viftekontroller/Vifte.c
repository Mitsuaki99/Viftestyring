/*
 * Vifte.c
 *
 * Created: 24.04.2023 18:18:57
 *  Author: mitsu
 */ 

#define F_CPU 4000000UL // Definerer CPU frekvensen for delay funksjonen
#define PERIOD_VALUE (0x14) //Setter perioden til 20

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include "main.h"


uint16_t adcVal;
float calculateTemp(uint16_t ADC_value);


float calculateTemp(uint16_t ADC_value)
{
	/* Denne funksjonen regner om verdien fra termistoren til grader i celsius, metoden er 
	basert p� denne koden: https://www.circuitbasics.com/arduino-thermistor-temperature-sensor-tutorial/ */
	float R1 = 10000;
	float logR2 , R2 , Temp , TempC;
	float c1 = 1.009249522e-03 , c2 = 2.378405444e-04 , c3 = 2.019202697e-07;
	R2 = R1 * (1023.0 / ( float ) ADC_value - 1.0);
	logR2 = log ( R2 );
	Temp = (1.0 /(c1 + c2 * logR2 + c3 * logR2 * logR2 * logR2));
	TempC = Temp - 273.15;
	return TempC;
}

void Auto(void)
{
	/* Henter verdien fra termistoren ved � bruke ADC, denne verdien blir s� kj�rt
	inn i funksjonen calculateTemp */
	adcVal = ADC0_read();
	float result = calculateTemp(adcVal);
	/* Beregner PWM verdien som sendes til viften basert p� temperaturen fra termistoren,
	minste temperatur, maks PWM verdi, min PWM verdi og maks temperatur*/
	float  PWM_value = (result - 0) * (20 - 0)/(50 - 0) + 0;
	TCA0.SINGLE.CMP0BUF = PWM_value;
	TCA0.SINGLE.CMP1BUF = PWM_value;
	TCA0.SINGLE.CMP2BUF = PWM_value;
	/* Printer s� ut b�de temperaturen og PWM verdien */
 	printf ("Temperature is: %.2f \r\n", result);
 	printf ("PWM Value is: %.2f \r\n", PWM_value);
 	printf ("Press 1 to cancel auto \r\n");
}

void Viftekontroll2(void)
{
	TCA0.SINGLE.CMP0BUF = 10;
	TCA0.SINGLE.CMP1BUF = 10;
	TCA0.SINGLE.CMP2BUF = 10;
	/* Printer s� ut PWM verdien */
 	printf ("PWM Value is 10 and is 50 percent of max \r\n");
}

void Viftekontroll3(void)
{
	TCA0.SINGLE.CMP0BUF = 20;
	TCA0.SINGLE.CMP1BUF = 20;
	TCA0.SINGLE.CMP2BUF = 20;
	/* Printer s� ut PWM verdien */
	printf ("PWM Value is 20 and is max \r\n");
}

void Viftekontroll_off(void)
{
	TCA0.SINGLE.CMP0BUF = 0;
	TCA0.SINGLE.CMP1BUF = 0;
	TCA0.SINGLE.CMP2BUF = 0;
}

void Diagnostics(void)
{
	TCA0.SINGLE.CMP0BUF = 0;
	TCA0.SINGLE.CMP1BUF = 0;
	TCA0.SINGLE.CMP2BUF = 0;
	
	_delay_ms(3000);
	
	TCA0.SINGLE.CMP0BUF = 20;
	TCA0.SINGLE.CMP1BUF = 20;
	TCA0.SINGLE.CMP2BUF = 20;
	
	_delay_ms(2000);
}

void menu_system(void){
	char received_char = USART3_receive();
	switch(received_char){
		// Hver case styrer hvordan viftene skal oppf�re seg
		case '1':
		printf("Fans sett to 50 percent \r\n");
		Viftekontroll2();
		break;
		case'2':
		printf("Fans sett to 100 percent \r\n");
		Viftekontroll3();
		break;
		case '3':
		printf("Fans sett to auto \r\n");
		while(1)
		{
			received_char = USART3_receive();
			if(received_char == '1')
			{
				USART3_menu_overview();
				break;
			}
			Auto();
			_delay_ms(3000);		
		}
		break;
		case '4':
		adcVal = ADC0_read();
		float result = calculateTemp(adcVal);
		printf("The temperature is: %f \r\n", result);
		break;
		case '5':
		printf("Fans are put in Diagnostics mode \r\n");
		for (int i = 0; i < 10; i++)
		{
			Diagnostics();
			// Her skulle funksjonen for turtelling v�rt implementert
			_delay_ms(500);
		}
		Viftekontroll_off();
		break;
		case '6':
		printf("Fans are turned off \r\n");
		Viftekontroll_off();
		break;
		default:
		;
		break;
	}
}
	

