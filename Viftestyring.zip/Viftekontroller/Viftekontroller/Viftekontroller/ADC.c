/*
 * ADC.c
 *
 * Created: 24.04.2023 18:10:41
 *  Author: mitsu
 */ 

#include <avr/io.h>

void ADC0_init(void)
{
	/* Deaktiverer digital input buffer for PORT D pin 6 */
	PORTD.PIN6CTRL &= ~PORT_ISC_gm;
	PORTD.PIN6CTRL |= PORT_ISC_INPUT_DISABLE_gc;
	/* Deaktiverer pull-up resistor for port D6 */
	PORTD.PIN6CTRL &= ~PORT_PULLUPEN_bm;
	/* Setter prescaler for ADC-klokken til 4 (CLK_PER delt p� 4) */
	ADC0.CTRLC = ADC_PRESC_DIV4_gc; 
	
	/* Konfigurerer ADC-kontrollregister A og setter den til 10 bits modus */
	ADC0.CTRLA = ADC_ENABLE_bm 
	| ADC_RESSEL_10BIT_gc; 
	
	/* Setter referanse til VDD */
	VREF.ADC0REF = VREF_REFSEL_VDD_gc; 
	
	/* Velger ADC-kanal */
	ADC0.MUXPOS = ADC_MUXPOS_AIN6_gc;
}

uint16_t ADC0_read(void)
{
	/* Starter ADC konvertering */
	ADC0.COMMAND = ADC_STCONV_bm;
	/* Venter til ADC konverteringen er ferdig */
	while ( !(ADC0.INTFLAGS & ADC_RESRDY_bm) )
	{
		;
	}
	/* Nullstiller flaggbitten for interrupt */
	ADC0.INTFLAGS = ADC_RESRDY_bm;
	/* Returnerer ADC-verdien */
	return ADC0.RES;
}