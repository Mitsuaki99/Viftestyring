/*
 * PORT.c
 *
 * Created: 24.04.2023 18:35:28
 *  Author: mitsu
 */ 

#include <avr/io.h>

void PORT_init(void)
{
	/* Setter pin 0, 1 and 2 i PORT D til output */
	PORTD.DIRSET = PIN0_bm | PIN1_bm | PIN2_bm;
	
	// Setter opp pull-up motstanden p� TACO-pinnene
	PORTD.PIN7CTRL = PORT_PULLUPEN_bm | PORT_ISC_FALLING_gc;
	PORTD.PIN5CTRL = PORT_PULLUPEN_bm | PORT_ISC_FALLING_gc;
	// Setter pin 1 og pin 2 som input p� PORT D
	PORTD.DIRCLR = PIN7_bm | PIN5_bm;
}