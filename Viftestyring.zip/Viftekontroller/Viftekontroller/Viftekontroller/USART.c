/*
 * USART.c
 *
 * Created: 24.04.2023 18:02:50
 *  Author: mitsu
 */ 

#define F_CPU 4000000UL // Definerer CPU frekvensen for delay funksjonen
#define USART3_BAUD_RATE(BAUD_RATE)((float)(64*4000000/(16 *(float)BAUD_RATE))+0.5)

#include <avr/io.h>
#include <stdio.h>
#include <string.h>

void USART3_init(void);
static void USART3_sendChar(char c);
static int USART3_printChar(char c, FILE *stream);
void USART3_sendString(char *str);
void USART3_menu_overview(void);

static FILE USART_stream = FDEV_SETUP_STREAM(USART3_printChar, NULL, _FDEV_SETUP_WRITE);

void USART3_init(void)
/* Denne funksjonen setter baud-raten og hvilke pinner som skal sende og motta */
{
	PORTB.DIR &= ~PIN1_bm;
	PORTB.DIR |= PIN0_bm;
	USART3.BAUD = (uint16_t)USART3_BAUD_RATE(9600); /* Bestemmer baud-raten til 9600 */
	USART3.CTRLB |= USART_TXEN_bm | USART_RXCIE_bm | USART_RXEN_bm;
	USART3.CTRLA |= USART_RXCIE_bm;
	stdout = &USART_stream;
}

void USART3_sendString(char *str) //string med type char
{
	for(size_t i = 0; i < strlen(str); i++) //for loop
	{
		USART3_sendChar(str[i]); // sender USART3_sendChar string
	}
}

static void USART3_sendChar(char c)
{
	while (!(USART3.STATUS & USART_DREIF_bm))
	// Venter p� at USART3 senderregistre er klart for sending 
	{
		;
	}
	USART3.TXDATAL = c;
}

static int USART3_printChar(char c, FILE *stream)
{
	USART3_sendChar(c);
	return 0;
}


void USART3_menu_overview(void){
	USART3_sendString("Select your setting for the fans: \n");
	USART3_sendString("1. 50% \n");
	USART3_sendString("2. 100% \n");
	USART3_sendString("3. Auto \n");
	USART3_sendString("4. Print temperature \n");
	USART3_sendString("5. Diagnostics \n");
	USART3_sendString("6. Off \n");
}

char USART3_receive(void){
	if (!(USART3.STATUS & USART_RXCIF_bm)){
		return 0;
	}
	else{
		return USART3_RXDATAL;
	}
}