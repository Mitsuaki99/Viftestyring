/*
 * Turteller.c
 *
 * Created: 01.05.2023 22:10:49
 * Author : mitsu
 */ 

#define F_CPU 4000000UL

#include <avr/interrupt.h>
#include <avr/io.h>
#include <avr/delay.h>
#include "UART.h"


void tcb0_setup(void);
void tcb0_read(void);
void TCA0_init(void);
int calculateRPM(int N);
void Viftekontroll(void);

int glob_pulse_count;
int glob_pulse_count2;

ISR(PORTD_PORT_vect){
	
	if(PORTD.INTFLAGS & PIN7_bm){
		glob_pulse_count++;
		PORTD.INTFLAGS = PIN7_bm;
	}
	
	if(PORTD.INTFLAGS & PIN7_bm){
		glob_pulse_count2++;
		PORTD.INTFLAGS = PIN7_bm;
	}
	
}



int main(void)
{
	USART3_init();
	tcb0_setup();
	pin_init();
	TCA0_init();
	
	sei();
	
	//TIMER_0_init();
	
	Viftekontroll();
	while (1)
	{
		// READ PULSE
		_delay_ms(1000); // READ EVERY sec
		
		printf("RPM:%d\n",calculateRPM(glob_pulse_count));
		glob_pulse_count = 0;
		
		
		//tcb0_read();
	}
	
	return 0;
}

#define PERIOD_VALUE (0x14)


void TCA0_init(void)
{
	
	PORTD.DIRSET = PIN0_bm | PIN1_bm | PIN2_bm;	
 	/* Setter b�lgeform utganger p� PORT D */
	PORTMUX.TCAROUTEA = PORTMUX_TCA0_PORTD_gc;
	TCA0.SINGLE.CTRLB = TCA_SINGLE_CMP0EN_bm | TCA_SINGLE_CMP1EN_bm | TCA_SINGLE_CMP2EN_bm/* Skrur p� "compare channel 0, 1, 2" */
	| TCA_SINGLE_WGMODE_DSBOTTOM_gc; /* Setter dual - slope PWM modus */
	
	/* Setter PWM frekvens og arbeidssyklus */
	TCA0.SINGLE.PERBUF = PERIOD_VALUE;
	TCA0.SINGLE.CMP0BUF = 0;
	TCA0.SINGLE.CTRLA = TCA_SINGLE_CLKSEL_DIV4_gc /* Setter "clock source" ( sys_clk /4) */
	| TCA_SINGLE_ENABLE_bm; /* Starter timeren */
}

void Viftekontroll(void)
{
	TCA0.SINGLE.CMP0BUF = 0;
	TCA0.SINGLE.CMP1BUF = 0;
	TCA0.SINGLE.CMP2BUF = 0;
}


int calculateRPM(int N){
	// KAN GJ�RES til float.
	int rpm_scaler = 5000/433;		// 433hz er max freq lest av scoop.
	
	int RPM = rpm_scaler*N;
	
	return RPM;
}



void tcb0_setup(void){
	
	TCB0.CTRLA |= TCB_ENABLE_bm;			// NO CLOCK SCALING. ENABLE TIMER
	TCB0.CTRLB |= TCB_CNTMODE_FRQ_gc;		// SET FREQ MEASUREMENT MODE.
	
	// CONTROL REGISTER B
}
//Denne delen fungerer ikke. Men optimalt ville denne gitt ut frekvensen.
// void tcb0_read(void){
// 	int reg_value = TCB0.CCMP;
// 	printf("Reg value: %d\n", reg_value);
// }

void pin_init(void){

	// 	PORTA.PIN2CTRL = PORT_PULLUPEN_bm | PORT_ISC_RISING_gc;
	// 	PORTA.DIRCLR = PIN2_bm;
	//
	// 	PORTD.PIN7CTRL = PORT_PULLUPEN_bm | PORT_ISC_FALLING_gc;
	// 	PORTF.PIN4CTRL = PORT_PULLUPEN_bm | PORT_ISC_FALLING_gc;
	
	PORTD.DIRCLR |= PIN7_bm;
	PORTD.PIN7CTRL = PORT_PULLUPEN_bm | PORT_ISC_FALLING_gc;
}

